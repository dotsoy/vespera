CREATE TABLE qiming_timeseries.daily_quotes
(
    `trade_date` Date,
    `symbol` String,
    `open_price` Float64,
    `close_price` Float64,
    `high_price` Float64,
    `low_price` Float64,
    `vol` Int64,
    `amount` Float64,
    `amplitude` Float64,
    `pct_chg` Float64,
    `change_amount` Float64,
    `turnover_rate` Float64,
    `ts_code` String,
    `pre_close` Float64
)
ENGINE = MergeTree
ORDER BY (ts_code, trade_date)
SETTINGS index_granularity = 8192
